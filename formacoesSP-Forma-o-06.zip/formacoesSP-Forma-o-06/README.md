# Site para divulgação dos projetos feitos no curso Scratch: desenvolvendo jogos através da programação

Fizemos esse site para trabalharmos desenvolvimento web ao longo de nossas formações
